# Dossiê Pessoa Física Otimizado

Este pacote contém a versão modularizada do `dossie_cpf.xml`, reorganizada para:
- separar consulta-base, enriquecimento e agregação;
- reduzir acoplamento entre apresentação e regra de dados;
- facilitar materialização incremental em Parquet;
- suportar visualização em Python + Polars.

## Estrutura

- `source/`: XML original usado como insumo.
- `sql_raw/`: consultas extraídas do XML original.
- `sql_otimizado/`: consultas atomizadas e reorganizadas por domínio.
- `docs/`: plano de implementação, ordem de execução e matriz de dependências.
- `examples/`: exemplo de pipeline em Polars.

## Observações

1. As consultas em `sql_otimizado/` foram reestruturadas para uso analítico e agregação posterior.
2. Os nomes `vw_*` usados em algumas consultas representam views intermediárias recomendadas.
3. Antes de produção, valide:
   - nomes exatos de colunas;
   - semântica das flags `in_ultima`, `it_in_ultima_fac`, etc.;
   - performance dos joins remotos e funções de string;
   - consistência de datas armazenadas como texto.

## Domínios cobertos

- Base da pessoa física e alerta de ITCD
- Empresas em que é/foi sócio(a)
- Veículos
- Endereços
- Conta corrente
- DIMP
- NFe de consumo
- Eleições / TSE
- Autos de infração
- Processos administrativos
