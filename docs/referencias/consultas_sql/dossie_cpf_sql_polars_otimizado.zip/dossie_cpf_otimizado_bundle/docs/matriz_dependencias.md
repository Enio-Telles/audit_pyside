# Matriz de dependências

| Consulta | Depende de | Tipo |
|---|---|---|
| 04_itcd_obito_consolidado | 02_itcd_antigo_obito, 03_itcd_novo_obito | agregação |
| 05_pessoa_fisica_dossie_header | 01_pessoa_fisica_base, 04_itcd_obito_consolidado | composição |
| 12_socios_empresas_agregado | 10_socios_empresas_base, 11_socios_empresas_inadimplencia | composição |
| 22_veiculos_unificados | 20_veiculos_atuais, 21_veiculos_historicos | união |
| 31_outros_enderecos_unificados | 25, 26, 27, 28, 29, 30 | união |
| 41_conta_corrente_classificada | 40_conta_corrente_base | enriquecimento |
| 42_conta_corrente_agregado | 41_conta_corrente_classificada | agregação |
| 43_conta_corrente_detalhe | 41_conta_corrente_classificada | drilldown |
| 45_dimp_agregado | 44_dimp_base | agregação |
| 51_nfe_consumo_agregado | 50_nfe_consumo_item | agregação |
| 73_autos_agregado | 70_autos_base, 71_autos_solidarios_tributo, 72_autos_solidarios_multa | composição |
| 74_autos_descricao | independente por auto | drilldown |
