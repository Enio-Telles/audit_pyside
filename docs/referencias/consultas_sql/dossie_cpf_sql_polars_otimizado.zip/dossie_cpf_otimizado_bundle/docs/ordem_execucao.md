# Ordem sugerida de execução

## Etapa 1 — resolução da base
1. 00_parametros_normalizados.sql
2. 01_pessoa_fisica_base.sql
3. 02_itcd_antigo_obito.sql
4. 03_itcd_novo_obito.sql
5. 04_itcd_obito_consolidado.sql
6. 05_pessoa_fisica_dossie_header.sql

## Etapa 2 — domínios independentes
### Societário
- 10_socios_empresas_base.sql
- 11_socios_empresas_inadimplencia.sql
- 12_socios_empresas_agregado.sql

### Veículos
- 20_veiculos_atuais.sql
- 21_veiculos_historicos.sql
- 22_veiculos_unificados.sql

### Endereços
- 23_endereco_itcd.sql
- 24_endereco_nfe_destinatario.sql
- 25_outros_enderecos_detran.sql
- 26_outros_enderecos_tse.sql
- 27_outros_enderecos_sitafe.sql
- 28_outros_enderecos_crc.sql
- 29_outros_enderecos_itcd.sql
- 30_outros_enderecos_cv115.sql
- 31_outros_enderecos_unificados.sql

### Financeiro
- 40_conta_corrente_base.sql
- 41_conta_corrente_classificada.sql
- 42_conta_corrente_agregado.sql
- 43_conta_corrente_detalhe.sql
- 44_dimp_base.sql
- 45_dimp_agregado.sql

### Documental
- 50_nfe_consumo_item.sql
- 51_nfe_consumo_agregado.sql

### Eventos externos
- 60_tse_candidaturas.sql

### Contencioso
- 70_autos_base.sql
- 71_autos_solidarios_tributo.sql
- 72_autos_solidarios_multa.sql
- 73_autos_agregado.sql
- 74_autos_descricao.sql

### Administrativo
- 80_processos_administrativos.sql

## Etapa 3 — materialização
- gravar Bronze por domínio
- padronizar Silver em Polars
- gerar Gold para a UI
