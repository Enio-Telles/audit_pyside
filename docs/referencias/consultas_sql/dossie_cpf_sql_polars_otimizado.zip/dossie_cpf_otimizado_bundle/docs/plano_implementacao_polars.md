# Plano de implementação da visualização otimizada do dossiê em Python + Polars

## 1. Objetivo

Implementar um dossiê de pessoa física em arquitetura analítica, com:
- extração modular a partir do banco transacional;
- persistência em Parquet por domínio;
- consumo lazy com Polars;
- composição visual de painéis, tabelas e drilldowns;
- integração com outra base de dados já disponível em Parquet.

## 2. Princípios de arquitetura

### 2.1 Camadas
- **Bronze**: extração quase bruta das consultas base.
- **Silver**: padronização de tipos, chaves e nomenclatura.
- **Gold**: tabelas de dossiê e agregados finais para a UI.

### 2.2 Chave principal
Use `cpf` normalizado como chave primária de integração.

### 2.3 Separação de responsabilidades
- SQL: captura e enriquecimento relacional.
- Polars: padronização, joins com Parquet, agregações finais, cálculo de métricas de UI.
- UI: apenas apresentação, filtros, drilldown e exportação.

## 3. Domínios sugeridos no lake Parquet

### 3.1 Bronze
- `bronze/pf_header/`
- `bronze/pf_socios_empresas/`
- `bronze/pf_veiculos/`
- `bronze/pf_enderecos_nfe/`
- `bronze/pf_outros_enderecos/`
- `bronze/pf_conta_corrente/`
- `bronze/pf_conta_corrente_detalhe/`
- `bronze/pf_nfe_consumo/`
- `bronze/pf_tse/`
- `bronze/pf_dimp/`
- `bronze/pf_autos/`
- `bronze/pf_autos_descricao/`
- `bronze/pf_processos_adm/`

### 3.2 Silver
- tipagem correta de datas e valores;
- deduplicação de linhas estruturais;
- colunas sem HTML;
- normalização de códigos de situação;
- colunas `source_system`, `snapshot_date`, `load_ts`.

### 3.3 Gold
- `gold/dossie_pf_header.parquet`
- `gold/dossie_pf_cards.parquet`
- `gold/dossie_pf_socios.parquet`
- `gold/dossie_pf_enderecos.parquet`
- `gold/dossie_pf_eventos_financeiros.parquet`
- `gold/dossie_pf_documentos.parquet`
- `gold/dossie_pf_contencioso.parquet`

## 4. Integração com outra base Parquet

## 4.1 Estratégia
A outra base Parquet deve ser integrada por `cpf` ou por chaves secundárias derivadas, como:
- `cnpj_empresa`
- `chave_acesso`
- `nu_termo_infracao`
- `nu_processo`

## 4.2 Boas práticas
- usar `pl.scan_parquet()` em vez de `read_parquet()` sempre que possível;
- padronizar CPF como string sem máscara;
- tratar datas no momento da leitura Silver;
- evitar join wide prematuro;
- materializar apenas conjuntos Gold necessários para a UI.

## 5. Fluxo de execução sugerido

1. Executar consultas de base do contribuinte.
2. Executar domínios independentes em paralelo:
   - societário
   - veículos
   - endereços
   - financeiro
   - documental
   - contencioso
   - administrativo
3. Gravar Bronze em Parquet por domínio.
4. Rodar tratamento Silver em Polars.
5. Integrar com a outra base Parquet.
6. Produzir camadas Gold e tabelas de apresentação.
7. Servir UI.

## 6. Modelo de visualização sugerido

### 6.1 Abas principais
- Identificação
- Vínculos societários
- Endereços e veículos
- Financeiro
- NFe / consumo
- Eventos externos
- Contencioso
- Processos administrativos

### 6.2 Componentes
- cartões-resumo
- grids filtráveis
- timeline por evento
- drilldown de autos
- detalhes de receitas / guias
- exportação CSV / Parquet de subconjuntos

## 7. Indicadores úteis para a UI

- quantidade de empresas vinculadas
- quantidade de empresas com inadimplência
- valor total inadimplente indireto
- quantidade de veículos atuais e históricos
- quantidade de endereços por fonte
- valor total em conta corrente por situação
- total de operações DIMP
- valor total de consumo em NFe
- quantidade e valor de autos de infração
- quantidade de processos administrativos

## 8. Recomendações de implementação em Polars

### 8.1 Convenções
- nomes de colunas em snake_case;
- datas convertidas para `Date` ou `Datetime`;
- valores monetários em `Decimal` ou `Float64`, conforme restrição do ambiente;
- colunas de apresentação criadas só no estágio final.

### 8.2 Performance
- priorizar `LazyFrame`;
- usar `select()` para projeção mínima;
- evitar `collect()` cedo demais;
- particionar Parquet por domínio e, se necessário, por ano;
- persistir agregados Gold prontos para a UI.

### 8.3 Qualidade
- testes de contagem por domínio;
- testes de unicidade de chave;
- testes de integridade referencial por CPF;
- trilha de auditoria com `snapshot_date`.

## 9. Ferramentas sugeridas

- **Polars** para transformação analítica
- **PyArrow** para controle fino de Parquet
- **DuckDB** opcional para debug e cruzamentos rápidos
- **Streamlit** ou **FastAPI + frontend** para UI
- **oracledb** para extração do banco origem

## 10. Riscos a observar

- campos com datas em texto no formato `YYYYMMDD`;
- joins por `substr()` que podem custar caro na extração;
- linhas sintéticas de total no SQL original;
- HTML embutido nas consultas antigas;
- divergência entre dados atuais e históricos em cadastro e endereços;
- cardinalidade alta em NFe de consumo.

## 11. Estratégia de migração recomendada

1. Manter o XML antigo apenas como referência.
2. Criar views SQL modulares.
3. Validar paridade de resultado com o dossiê antigo.
4. Materializar Bronze/Silver/Gold.
5. Substituir o front por uma visualização desacoplada do SQL de apresentação.
