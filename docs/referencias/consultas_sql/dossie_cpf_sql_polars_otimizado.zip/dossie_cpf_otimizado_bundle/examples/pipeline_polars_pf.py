from __future__ import annotations

from pathlib import Path
import polars as pl

BASE = Path("data")

def scan(path: str) -> pl.LazyFrame:
    return pl.scan_parquet(BASE / path)

def normalize_cpf(expr: pl.Expr) -> pl.Expr:
    return expr.cast(pl.Utf8).str.replace_all(r"\D+", "").str.zfill(11)

def build_header() -> pl.LazyFrame:
    header = scan("silver/pf_header.parquet").with_columns(
        normalize_cpf(pl.col("cpf")).alias("cpf")
    )
    return header

def build_socios() -> pl.LazyFrame:
    socios = scan("silver/pf_socios_empresas.parquet").with_columns(
        normalize_cpf(pl.col("cpf_socio")).alias("cpf_socio"),
        pl.col("valor_inadimplente").cast(pl.Float64)
    )
    return socios

def build_financeiro() -> pl.LazyFrame:
    cc = scan("silver/pf_conta_corrente.parquet").with_columns(
        normalize_cpf(pl.col("cpf")).alias("cpf"),
        pl.col("valor").cast(pl.Float64)
    )
    return cc

def integrate_external_parquet() -> pl.LazyFrame:
    # exemplo: outra base com sinais complementares por CPF
    ext = scan("external/outra_base_pf.parquet").with_columns(
        normalize_cpf(pl.col("cpf")).alias("cpf")
    )
    return ext

def build_gold_cards() -> pl.DataFrame:
    header = build_header()
    socios = build_socios()
    financeiro = build_financeiro()
    ext = integrate_external_parquet()

    cards = (
        header
        .join(
            socios.group_by("cpf_socio").agg([
                pl.len().alias("qtd_empresas_vinculadas"),
                pl.col("valor_inadimplente").sum().alias("valor_inadimplente_indireto")
            ]),
            left_on="cpf",
            right_on="cpf_socio",
            how="left"
        )
        .join(
            financeiro.group_by("cpf").agg([
                pl.col("valor").sum().alias("valor_total_conta_corrente")
            ]),
            on="cpf",
            how="left"
        )
        .join(ext, on="cpf", how="left")
        .select([
            "cpf", "nome", "municipio", "uf",
            "indicio_obito_itcd", "qtd_processos",
            "qtd_empresas_vinculadas", "valor_inadimplente_indireto",
            "valor_total_conta_corrente"
        ])
    )
    return cards.collect()

if __name__ == "__main__":
    df = build_gold_cards()
    print(df)
