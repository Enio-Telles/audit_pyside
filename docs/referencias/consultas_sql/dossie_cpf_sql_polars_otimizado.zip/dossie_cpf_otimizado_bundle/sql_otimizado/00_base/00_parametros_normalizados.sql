-- Resolve a chave principal do dossiê de pessoa física.
-- Saída: cpf_normalizado, nome_normalizado
SELECT
    REGEXP_REPLACE(:CPF, '\D+', '') AS cpf_normalizado,
    UPPER(TRIM(:NOME))               AS nome_normalizado
FROM dual;
