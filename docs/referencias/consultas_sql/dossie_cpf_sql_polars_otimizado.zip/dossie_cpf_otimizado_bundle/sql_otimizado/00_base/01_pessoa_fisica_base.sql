-- Base cadastral principal da pessoa física.
SELECT
    p.co_cnpj_cpf              AS cpf,
    p.no_razao_social          AS nome,
    p.desc_endereco            AS logradouro,
    p.bairro,
    p.nu_cep                   AS cep,
    l.no_municipio             AS municipio,
    l.co_uf                    AS uf,
    p.co_municipio
FROM bi.dm_pessoa p
LEFT JOIN bi.dm_localidade l
       ON p.co_municipio = l.co_municipio
WHERE LENGTH(p.co_cnpj_cpf) = 11
  AND (:CPF IS NULL  OR p.co_cnpj_cpf = REGEXP_REPLACE(:CPF, '\D+', ''))
  AND (:NOME IS NULL OR UPPER(p.no_razao_social) LIKE '%' || REGEXP_REPLACE(UPPER(:NOME), '\s', '%') || '%');
