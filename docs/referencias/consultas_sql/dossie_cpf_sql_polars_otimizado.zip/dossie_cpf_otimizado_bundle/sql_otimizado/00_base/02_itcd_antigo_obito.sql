-- Processos de inventário do sistema antigo do ITCD.
SELECT
    proc.nu_ident_inventariado AS cpf_de_cujus,
    prot.da_envio              AS data_envio,
    prot.co_protocolo          AS numero_processo
FROM itcd_prod.tri_itd_processo  proc
JOIN itcd_prod.tri_itd_protocolo prot
  ON proc.fk_protocolo = prot.pk_protocolo
JOIN itcd_prod.tri_itd_fato_gerador fg
  ON fg.pk_fato_gerador = prot.fk_fato_gerador
WHERE prot.fk_fato_gerador = 1
  AND prot.fk_situacao = 5;
