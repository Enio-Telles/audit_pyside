-- Processos de inventário do sistema novo do ITCD.
SELECT
    inv.cpf_cnpj            AS cpf_de_cujus,
    proc.data_envio         AS data_envio,
    proc.numero_processo    AS numero_processo
FROM ITCD.processos     proc
JOIN itcd.inventariados inv
  ON proc.id = inv.processo_id
WHERE proc.fato_gerador_id = 1
  AND proc.situacao_id = 5;
