-- Consolida indícios de óbito por inventário e prepara o resumo para o dossiê.
WITH itcd_union AS (
    SELECT cpf_de_cujus, data_envio, numero_processo
      FROM vw_pf_itcd_antigo_obito
    UNION ALL
    SELECT cpf_de_cujus, data_envio, numero_processo
      FROM vw_pf_itcd_novo_obito
)
SELECT
    cpf_de_cujus,
    COUNT(*) AS qtd_processos,
    LISTAGG(numero_processo, ' * ') WITHIN GROUP (ORDER BY data_envio DESC) AS numeros_processo,
    MAX(data_envio) AS data_mais_recente
FROM itcd_union
GROUP BY cpf_de_cujus;
