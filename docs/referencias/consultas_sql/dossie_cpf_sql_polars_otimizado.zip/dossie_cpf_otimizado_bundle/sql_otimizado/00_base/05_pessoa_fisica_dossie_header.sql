-- Cabeçalho limpo do dossiê, sem HTML de apresentação.
SELECT
    b.cpf,
    b.nome,
    b.logradouro,
    b.bairro,
    b.cep,
    b.municipio,
    b.uf,
    i.qtd_processos,
    i.numeros_processo,
    CASE WHEN i.cpf_de_cujus IS NOT NULL THEN 1 ELSE 0 END AS indicio_obito_itcd,
    'https://itcd.sefin.ro.gov.br/visualizar_consulta_autenticacao_sistemas_sefin' AS link_itcd
FROM vw_pf_pessoa_base b
LEFT JOIN vw_pf_itcd_obito_consolidado i
       ON b.cpf = i.cpf_de_cujus;
