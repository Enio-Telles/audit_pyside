-- Empresas em que a pessoa é/foi sócia: base sem formatação.
SELECT
    SUBSTR(t.gr_identificacao, 2)                                          AS cpf_socio,
    p.co_cnpj_cpf                                                          AS cnpj_empresa,
    h.it_nu_inscricao_estadual                                             AS ie_empresa,
    p.no_razao_social                                                      AS nome_empresa,
    l.no_municipio                                                         AS municipio_empresa,
    p.in_situacao                                                          AS codigo_situacao,
    p.in_situacao || ' - ' || s.no_situacao                                AS situacao_empresa,
    p.co_regime_pagto || ' - ' || r.no_regime_pagamento                    AS regime_pagamento,
    p.da_inicio_atividade                                                  AS inicio_atividade,
    MIN(h.it_da_referencia) OVER(PARTITION BY h.it_nu_inscricao_estadual, t.gr_identificacao) AS dt_entrada_raw,
    MAX(h.it_da_referencia) OVER(PARTITION BY h.it_nu_inscricao_estadual, t.gr_identificacao) AS dt_saida_raw,
    MAX(h.it_in_ultima_fac) OVER(PARTITION BY h.it_nu_inscricao_estadual, t.gr_identificacao) AS flag_ultima_fac
FROM sitafe.sitafe_historico_socio        t
LEFT JOIN sitafe.sitafe_historico_contribuinte h
       ON t.it_nu_fac = h.it_nu_fac
LEFT JOIN bi.dm_pessoa p
       ON SUBSTR(h.gr_identificacao, 2) = p.co_cnpj_cpf
LEFT JOIN bi.dm_localidade l
       ON p.co_municipio = l.co_municipio
LEFT JOIN bi.dm_regime_pagto_descricao r
       ON p.co_regime_pagto = r.co_regime_pagamento
LEFT JOIN bi.vw_situacao_contribuinte s
       ON p.in_situacao = s.in_situacao
WHERE SUBSTR(t.gr_identificacao, 2) = :CPF;
