-- Inadimplência por CNPJ da empresa vinculada ao sócio.
SELECT
    v.co_cnpj_cpf AS cnpj_empresa,
    SUM(v.va_principal + v.va_multa + v.va_juros + v.va_acrescimo) AS valor_inadimplente
FROM bi.fato_lanc_arrec_sum v
WHERE v.vencido = 3
  AND v.id_situacao = '01'
GROUP BY v.co_cnpj_cpf;
