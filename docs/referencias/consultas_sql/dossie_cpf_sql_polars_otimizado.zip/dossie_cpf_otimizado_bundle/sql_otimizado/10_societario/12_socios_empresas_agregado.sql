-- Visão agregada final para uso no dossiê.
SELECT DISTINCT
    b.cpf_socio,
    b.cnpj_empresa,
    b.ie_empresa,
    b.nome_empresa,
    b.municipio_empresa,
    b.codigo_situacao,
    b.situacao_empresa,
    b.regime_pagamento,
    b.inicio_atividade,
    TO_DATE(b.dt_entrada_raw, 'YYYYMMDD') AS inicio_participacao,
    CASE WHEN b.flag_ultima_fac = 9 THEN NULL ELSE TO_DATE(b.dt_saida_raw, 'YYYYMMDD') END AS fim_participacao,
    COALESCE(i.valor_inadimplente, 0) AS valor_inadimplente
FROM vw_pf_socios_empresas_base b
LEFT JOIN vw_pf_socios_empresas_inadimplencia i
       ON b.cnpj_empresa = i.cnpj_empresa;
