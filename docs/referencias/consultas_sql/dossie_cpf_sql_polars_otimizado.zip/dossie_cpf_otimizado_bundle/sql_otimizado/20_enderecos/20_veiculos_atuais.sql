SELECT
    2 AS codigo,
    tb.it_no_marca_modelo AS modelo,
    t.it_da_ano_fabricacao AS ano_fabricacao,
    t.it_da_ano_modelo AS ano_modelo,
    t.it_nu_placa AS placa,
    t.it_co_renavam AS renavam,
    t.it_nu_chassi AS chassi,
    'ATUAL' AS situacao_propriedade
FROM sitafe.sitafe_veiculo t
LEFT JOIN sitafe.sitafe_tab_veiculo tb
       ON t.it_co_marca_modelo = tb.it_co_marca_modelo
WHERE t.it_nu_devedor = :CPF;
