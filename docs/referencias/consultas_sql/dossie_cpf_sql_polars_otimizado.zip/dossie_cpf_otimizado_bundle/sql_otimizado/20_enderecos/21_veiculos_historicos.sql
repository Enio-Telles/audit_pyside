SELECT
    4 AS codigo,
    tb.it_no_marca_modelo AS modelo,
    t.ano_fabricacao,
    t.ano_modelo,
    t.placa,
    t.renavam,
    t.chassi,
    'HISTORICO' AS situacao_propriedade
FROM detran.log_cadastro t
LEFT JOIN sitafe.sitafe_tab_veiculo tb
       ON t.marca_modelo = tb.it_co_marca_modelo
WHERE SUBSTR(t.numero_devedor, 1, 11) = :CPF
  AND TRIM(t.chassi) NOT IN (
      SELECT TRIM(it_nu_chassi)
      FROM sitafe.sitafe_veiculo
      WHERE it_nu_devedor = :CPF
  )
GROUP BY tb.it_no_marca_modelo, t.ano_fabricacao, t.ano_modelo, t.placa, t.renavam, t.chassi;
