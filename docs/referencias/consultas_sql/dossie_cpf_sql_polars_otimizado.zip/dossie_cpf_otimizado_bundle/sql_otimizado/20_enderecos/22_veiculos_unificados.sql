SELECT * FROM vw_pf_veiculos_atuais
UNION ALL
SELECT * FROM vw_pf_veiculos_historicos;
