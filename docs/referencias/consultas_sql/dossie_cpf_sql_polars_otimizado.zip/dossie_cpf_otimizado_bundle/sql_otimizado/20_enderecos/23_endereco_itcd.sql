SELECT
    'ITCD' AS origem,
    NULL   AS ano_mes,
    UPPER(t.tx_logradouro)   AS logradouro,
    UPPER(t.tx_numero)       AS numero,
    UPPER(t.tx_complemento)  AS complemento,
    UPPER(t.tx_bairro)       AS bairro,
    UPPER(t.tx_telefone)     AS fone,
    UPPER(t.tx_cep)          AS cep,
    UPPER(t.tx_cidade)       AS municipio,
    UPPER(t.tx_estado)       AS uf,
    NULL                     AS valor_referencia
FROM itcd_prod.tri_itd_pessoa t
WHERE t.pk_pessoa = :CPF;
