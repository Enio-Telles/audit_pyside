SELECT
    'NFE' AS origem,
    EXTRACT(YEAR FROM dhemi) || '/' || EXTRACT(MONTH FROM dhemi) AS ano_mes,
    UPPER(xlgr_dest)    AS logradouro,
    UPPER(nro_dest)     AS numero,
    UPPER(xcpl_dest)    AS complemento,
    UPPER(xbairro_dest) AS bairro,
    UPPER(fone_dest)    AS fone,
    UPPER(cep_dest)     AS cep,
    UPPER(xmun_dest)    AS municipio,
    UPPER(co_uf_dest)   AS uf,
    MAX(tot_vnf)        AS valor_referencia
FROM bi.fato_nfe_detalhe
WHERE co_destinatario = :CPF
GROUP BY UPPER(xlgr_dest), UPPER(nro_dest), UPPER(xcpl_dest), UPPER(xbairro_dest),
         UPPER(fone_dest), UPPER(cep_dest), UPPER(xmun_dest), UPPER(co_uf_dest),
         EXTRACT(YEAR FROM dhemi) || '/' || EXTRACT(MONTH FROM dhemi);
