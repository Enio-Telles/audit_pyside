SELECT
    'DETRAN' AS fonte,
    t.data AS ordem,
    TO_CHAR(EXTRACT(YEAR FROM t.data) || '/' || EXTRACT(MONTH FROM t.data)) AS periodo,
    t.endereco,
    t.numero,
    t.complemento,
    t.bairro,
    m.it_no_municipio AS municipio,
    m.it_sg_uf        AS uf,
    t.cep,
    t.ddd || '-' || t.telefone AS telefone,
    NULL AS email
FROM detran.log_cadastro t
LEFT JOIN sitafe.sitafe_municipio_ipva m
       ON t.municipio = m.it_co_municipio_ant
WHERE SUBSTR(t.numero_devedor, 1, 11) = :CPF;
