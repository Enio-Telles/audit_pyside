SELECT
    'TSE' AS fonte,
    t.dt_eleicao AS ordem,
    TO_CHAR(EXTRACT(YEAR FROM t.dt_eleicao) || '/' || EXTRACT(MONTH FROM t.dt_eleicao)) AS periodo,
    NULL AS endereco,
    NULL AS numero,
    NULL AS complemento,
    NULL AS bairro,
    t.nm_ue AS municipio,
    t.sg_uf AS uf,
    NULL AS cep,
    NULL AS telefone,
    t.nm_email AS email
FROM bi.dm_candidatos t
WHERE t.nr_cpf_candidato = :CPF;
