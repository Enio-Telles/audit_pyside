SELECT
    'SITAFE' AS fonte,
    TO_DATE(t.it_da_transacao, 'YYYYMMDD') AS ordem,
    TO_CHAR(EXTRACT(YEAR FROM TO_DATE(t.it_da_transacao, 'YYYYMMDD')) || '/' ||
            EXTRACT(MONTH FROM TO_DATE(t.it_da_transacao, 'YYYYMMDD'))) AS periodo,
    t.it_tx_logradouro_corresp AS endereco,
    NULL AS numero,
    NULL AS complemento,
    t.it_no_bairro_corresp AS bairro,
    l.no_municipio AS municipio,
    l.co_uf AS uf,
    t.it_co_cep_corresp AS cep,
    t.it_nu_ddd_corresp || '-' || t.it_nu_telefone_corresp AS telefone,
    t.it_co_correio_eletro_corresp AS email
FROM sitafe.sitafe_pessoa t
LEFT JOIN bi.dm_localidade l
       ON t.it_co_municipio_corresp = l.co_municipio
WHERE SUBSTR(t.gr_identificacao, 2) = :CPF;
