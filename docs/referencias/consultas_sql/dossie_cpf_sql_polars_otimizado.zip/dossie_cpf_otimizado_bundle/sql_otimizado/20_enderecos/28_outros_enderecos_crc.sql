SELECT
    'CRC' AS fonte,
    c.created_at AS ordem,
    TO_CHAR(EXTRACT(YEAR FROM c.created_at) || '/' || EXTRACT(MONTH FROM c.created_at)) AS periodo,
    e.tipo_logradouro || ' ' || e.logradouro AS endereco,
    e.numero,
    e.complemento,
    e.bairro,
    e.cidade AS municipio,
    e.uf,
    e.cep,
    e.telefone,
    e.email
FROM app_crc.contadores c
LEFT JOIN app_crc.enderecos e
       ON c.id = e.contador_id
WHERE c.cpf_cnpj = :CPF;
