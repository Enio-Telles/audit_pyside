SELECT
    'ITCD' AS fonte,
    NULL AS ordem,
    NULL AS periodo,
    t.tx_logradouro AS endereco,
    t.tx_numero AS numero,
    t.tx_complemento AS complemento,
    t.tx_bairro AS bairro,
    t.tx_cidade AS municipio,
    t.tx_estado AS uf,
    t.tx_cep AS cep,
    t.tx_telefone AS telefone,
    NULL AS email
FROM itcd_prod.tri_itd_pessoa t
WHERE t.pk_pessoa = :CPF;
