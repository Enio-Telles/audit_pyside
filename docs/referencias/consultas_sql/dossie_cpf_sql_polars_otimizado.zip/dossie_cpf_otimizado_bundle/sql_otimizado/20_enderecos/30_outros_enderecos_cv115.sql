SELECT
    CASE
        WHEN cv115.modelo = '06' THEN 'CV115 - ENERGIA ELETRICA'
        WHEN cv115.modelo = '21' THEN 'CV115 - COMUNICACAO'
        WHEN cv115.modelo = '22' THEN 'CV115 - TELECOMUNICACAO'
    END AS fonte,
    TO_DATE(cv115.dt_emissao, 'YYYYMMDD') AS ordem,
    SUBSTR(cv115.dt_emissao, 1, 4) || '/' || SUBSTR(cv115.dt_emissao, 5, 2) AS periodo,
    cv115.logradouro AS endereco,
    cv115.numero_end AS numero,
    cv115.complemento,
    cv115.bairro,
    cv115.municipio,
    cv115.uf,
    cv115.cep,
    cv115.telefone,
    '' AS email
FROM novo_sisconv.dados_cadastrais cv115
WHERE cv115.cpf_cnpj LIKE '%' || :CPF;
