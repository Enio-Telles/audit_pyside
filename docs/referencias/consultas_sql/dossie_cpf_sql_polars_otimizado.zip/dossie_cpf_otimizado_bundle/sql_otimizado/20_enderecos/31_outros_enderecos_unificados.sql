SELECT * FROM vw_pf_outros_enderecos_detran
UNION ALL
SELECT * FROM vw_pf_outros_enderecos_tse
UNION ALL
SELECT * FROM vw_pf_outros_enderecos_sitafe
UNION ALL
SELECT * FROM vw_pf_outros_enderecos_crc
UNION ALL
SELECT * FROM vw_pf_outros_enderecos_itcd
UNION ALL
SELECT * FROM vw_pf_outros_enderecos_cv115;
