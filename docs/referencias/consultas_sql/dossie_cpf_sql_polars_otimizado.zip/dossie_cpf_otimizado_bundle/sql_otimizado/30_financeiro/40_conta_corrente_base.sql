SELECT
    t.id_cpf_cnpj AS cpf,
    t.id_situacao,
    s.it_no_situacao AS descricao_situacao,
    t.id_receita,
    t.da_vencimento,
    t.da_pagamento,
    t.nu_guia_parcela,
    t.nu_complemento,
    CASE
        WHEN t.va_pago IS NULL THEN (t.va_principal + t.va_multa + t.va_juros + t.va_acrescimo)
        ELSE t.va_pago
    END AS valor
FROM bi.fato_lanc_arrec t
LEFT JOIN bi.dm_situacao_lancamento s
       ON t.id_situacao = s.it_co_situacao
WHERE t.id_cpf_cnpj = :CPF;
