SELECT
    cpf,
    id_receita,
    da_vencimento,
    da_pagamento,
    nu_guia_parcela,
    nu_complemento,
    CASE
        WHEN id_situacao = '01' AND da_vencimento < SYSDATE THEN '01 - Não pago e Vencido'
        WHEN id_situacao = '01' AND da_vencimento > SYSDATE THEN '01 - Não pago a vencer'
        ELSE id_situacao || ' - ' || INITCAP(descricao_situacao)
    END AS situacao_classificada,
    valor
FROM vw_pf_conta_corrente_base;
