SELECT
    situacao_classificada,
    id_receita,
    SUM(valor) AS valor_total
FROM vw_pf_conta_corrente_classificada
GROUP BY situacao_classificada, id_receita;
