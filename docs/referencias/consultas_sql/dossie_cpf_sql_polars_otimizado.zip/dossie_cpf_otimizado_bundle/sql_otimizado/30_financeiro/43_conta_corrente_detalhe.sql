SELECT
    c.da_vencimento,
    c.da_pagamento,
    c.nu_guia_parcela,
    c.nu_complemento,
    c.id_receita,
    r.it_no_receita AS nome_receita,
    c.situacao_classificada,
    c.valor
FROM vw_pf_conta_corrente_classificada c
LEFT JOIN bi.dm_receita r
       ON c.id_receita = r.it_co_receita
WHERE (:SITUACAO IS NULL OR c.situacao_classificada = :SITUACAO);
