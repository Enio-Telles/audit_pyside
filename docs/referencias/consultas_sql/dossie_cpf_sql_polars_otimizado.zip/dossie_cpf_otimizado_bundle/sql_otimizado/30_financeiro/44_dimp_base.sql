SELECT
    t.cnpj,
    reg0100.cpf,
    reg1100.dt_ini,
    reg1100.dt_fin,
    reg1100.qtd,
    reg1100.valor
FROM dimp.reg0000s t
LEFT JOIN dimp.reg0100s reg0100
       ON t.id = reg0100.reg0000_id
LEFT JOIN dimp.reg1100s reg1100
       ON t.id = reg1100.reg0000_id
      AND reg0100.cod_cliente = reg1100.cod_cliente
WHERE reg0100.cpf = :CPF;
