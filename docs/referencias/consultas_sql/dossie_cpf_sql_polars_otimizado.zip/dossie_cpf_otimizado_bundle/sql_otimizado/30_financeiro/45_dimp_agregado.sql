SELECT
    EXTRACT(YEAR FROM dt_ini) AS ano,
    EXTRACT(YEAR FROM dt_ini) || '/' || EXTRACT(MONTH FROM dt_ini) AS periodo,
    SUM(qtd) AS operacoes,
    SUM(valor) AS valor_total
FROM vw_pf_dimp_base
GROUP BY GROUPING SETS (
    (),
    (EXTRACT(YEAR FROM dt_ini)),
    (EXTRACT(YEAR FROM dt_ini), EXTRACT(YEAR FROM dt_ini) || '/' || EXTRACT(MONTH FROM dt_ini))
);
