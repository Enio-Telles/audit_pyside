SELECT
    EXTRACT(YEAR FROM t.dhemi) AS ano,
    t.dhemi                    AS data_emissao,
    t.chave_acesso,
    t.co_emitente              AS cnpj_emitente,
    UPPER(t.xnome_emit)        AS nome_emitente,
    UPPER(t.xlgr_emit)         AS logradouro_emitente,
    UPPER(t.xbairro_emit)      AS bairro_emitente,
    t.nro_emit                 AS numero_emitente,
    UPPER(t.xcpl_emit)         AS complemento_emitente,
    UPPER(t.xmun_emit)         AS municipio_emitente,
    t.co_uf_emit               AS uf_emitente,
    UPPER(t.prod_xprod)        AS produto,
    t.prod_ucom                AS unidade,
    t.prod_qcom                AS quantidade,
    (t.prod_vprod + t.prod_vfrete + t.prod_vseg - t.prod_vdesc + t.prod_voutro) AS valor_item
FROM bi.fato_nfe_detalhe t
WHERE t.co_destinatario = :CPF
  AND t.infprot_cstat IN ('100', '150');
