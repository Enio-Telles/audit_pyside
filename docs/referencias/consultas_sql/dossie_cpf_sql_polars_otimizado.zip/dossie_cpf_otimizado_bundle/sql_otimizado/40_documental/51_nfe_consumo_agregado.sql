SELECT
    ano,
    cnpj_emitente,
    uf_emitente,
    chave_acesso,
    produto,
    SUM(valor_item) AS valor_total,
    SUM(quantidade) AS quantidade_total
FROM vw_pf_nfe_consumo_item
GROUP BY GROUPING SETS(
    (),
    (ano),
    (cnpj_emitente, nome_emitente),
    (uf_emitente),
    (ano, data_emissao, chave_acesso, cnpj_emitente, nome_emitente, logradouro_emitente,
     bairro_emitente, numero_emitente, complemento_emitente, municipio_emitente, uf_emitente,
     produto, unidade, quantidade)
);
