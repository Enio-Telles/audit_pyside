SELECT
    ds_eleicao            AS eleicao,
    ds_cargo              AS cargo,
    nm_ue || ' / ' || sg_uf AS local_eleicao,
    nm_candidato          AS nome_candidato,
    nm_urna_candidato     AS nome_urna,
    nm_email              AS email,
    sg_partido            AS partido,
    nm_municipio_nascimento || ' / ' || sg_uf_nascimento AS local_nascimento,
    dt_nascimento,
    nr_titulo_eleitoral_candidato AS titulo_eleitoral,
    ds_grau_instrucao     AS grau_instrucao,
    ds_estado_civil       AS estado_civil,
    ds_cor_raca           AS cor_raca,
    ds_ocupacao           AS ocupacao,
    ds_sit_tot_turno      AS resultado
FROM bi.dm_candidatos
WHERE nr_cpf_candidato = :CPF;
