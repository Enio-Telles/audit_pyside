SELECT
    t.da_lavratura_auto AS da_lavratura,
    t.nu_termo_infracao,
    UPPER(CONVERT(t.no_local_lavratura, 'AL32UTF8', 'WE8MSWIN1252')) AS local_lavratura,
    t.va_tributo,
    t.va_multa,
    t.va_juros,
    (t.va_tributo + t.va_multa + t.va_juros) AS total_auto,
    '  ' || t.da_periodo_inicio_auto || '    -    ' || t.da_periodo_final_auto || '  ' AS periodo_fiscalizado,
    t.nu_guia_lanc_trib,
    t.nu_guia_lanc_multa,
    tate.no_situacao AS situacao_tate
FROM bi.fato_acao_fiscal_ainf t
LEFT JOIN bi.dm_acao_fiscal u
       ON t.nu_acao_fiscal = u.nu_acao_fiscal
LEFT JOIN bi.dm_acao_fiscal_historico_tate tate
       ON t.nu_termo_infracao = tate.nu_termo_infracao
WHERE u.co_cnpj_cpf = :CPF
  AND tate.in_ultima = 9;
