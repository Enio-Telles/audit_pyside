SELECT
    d.it_nu_guia AS nu_guia,
    LISTAGG(p.co_cnpj_cpf || ' - ' || p.no_razao_social, ', ')
        WITHIN GROUP (ORDER BY d.it_nu_guia) AS solidarios_multa
FROM sitafe.sitafe_devedor_solidario d
LEFT JOIN bi.dm_pessoa p
       ON d.it_nu_cpf_cnpj_devedor = p.co_cnpj_cpf
GROUP BY d.it_nu_guia;
