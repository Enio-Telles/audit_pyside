SELECT
    a.da_lavratura,
    a.nu_termo_infracao,
    a.local_lavratura,
    SUM(a.va_tributo) AS va_tributo,
    SUM(a.va_multa) AS va_multa,
    SUM(a.va_juros) AS va_juros,
    SUM(a.total_auto) AS total,
    a.periodo_fiscalizado,
    a.situacao_tate,
    st.solidarios_tributo,
    sm.solidarios_multa
FROM vw_pf_autos_base a
LEFT JOIN vw_pf_autos_solidarios_tributo st
       ON st.nu_guia = a.nu_guia_lanc_trib
LEFT JOIN vw_pf_autos_solidarios_multa sm
       ON sm.nu_guia = a.nu_guia_lanc_multa
GROUP BY GROUPING SETS (
    (),
    (a.da_lavratura, a.nu_termo_infracao, a.local_lavratura, a.periodo_fiscalizado, a.situacao_tate,
     st.solidarios_tributo, sm.solidarios_multa)
);
