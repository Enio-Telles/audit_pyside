SELECT
    t.nu_termo_infracao,
    t.da_lavratura_auto,
    pessoa.no_razao_social AS sujeito_passivo,
    pessoa.co_cnpj_cpf     AS cpf_cnpj,
    pessoa.co_cad_icms     AS ie,
    CONVERT(t.tx_infracao, 'AL32UTF8', 'WE8MSWIN1252') AS historico_infracao,
    t.no_penalidade_auto   AS penalidade,
    LISTAGG(u.da_situacao || ' - ' || u.no_situacao, CHR(10))
        WITHIN GROUP (ORDER BY u.da_situacao) AS tramite_tate
FROM bi.fato_acao_fiscal_ainf t
LEFT JOIN bi.dm_acao_fiscal_historico_tate u
       ON t.nu_termo_infracao = u.nu_termo_infracao
LEFT JOIN bi.dm_acao_fiscal acao
       ON t.nu_acao_fiscal = acao.nu_acao_fiscal
LEFT JOIN bi.dm_pessoa pessoa
       ON acao.co_cnpj_cpf = pessoa.co_cnpj_cpf
WHERE t.nu_termo_infracao = :NU_TERMO_INFRACAO
GROUP BY t.nu_termo_infracao, t.da_lavratura_auto, t.no_penalidade_auto,
         t.tx_infracao, pessoa.no_razao_social, pessoa.co_cnpj_cpf, pessoa.co_cad_icms;
