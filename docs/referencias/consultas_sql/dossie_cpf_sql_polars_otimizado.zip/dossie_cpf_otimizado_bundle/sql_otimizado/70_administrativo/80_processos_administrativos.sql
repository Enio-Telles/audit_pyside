SELECT
    t.dt_abertura,
    t.nu_processo,
    t.co_servico,
    t.in_status,
    t.cpf_solicitante,
    serv.it_co_servico || ' - ' || UPPER(CONVERT(serv.it_no_servico, 'AL32UTF8', 'WE8MSWIN1252')) AS servico
FROM bi.dm_processo_administrativo t
LEFT JOIN sitafe.sitafe_servico serv
       ON t.co_servico = serv.it_co_servico
LEFT JOIN bi.dm_pessoa pessoa
       ON t.cpf_solicitante = pessoa.co_cnpj_cpf
WHERE t.co_cpf_cnpj_contribuinte = :CPF
ORDER BY t.dt_abertura DESC;
