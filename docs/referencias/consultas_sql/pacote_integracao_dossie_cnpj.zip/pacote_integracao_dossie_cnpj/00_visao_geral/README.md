# Pacote de integração do Dossiê CNPJ

Este pacote reúne:

1. inventário das buscas realizadas no repositório e no Google Drive;
2. explicação de como integrar o dossiê CNPJ ao projeto `audit_react`;
3. plano operacional para modo unitário e modo em lote;
4. proposta de estrutura de diretórios, serviços, pipeline e persistência;
5. cópia do pacote SQL/Polars originalmente enviado.

## Arquivos principais

- `01_buscas_e_fontes/01_inventario_buscas.md`
- `01_buscas_e_fontes/02_fontes_evidencias.md`
- `02_plano_integracao/01_guia_implementacao_dossie_cnpj.md`
- `02_plano_integracao/02_plano_lote_e_unitario.md`
- `02_plano_integracao/03_checklist_implementacao.md`
- `04_templates/manifesto_execucao_exemplo.json`

## Ideia central

O `audit_react` já possui a infraestrutura correta para processar dados por contribuinte.
A recomendação é criar o **Dossiê CNPJ como um novo domínio do projeto**, reaproveitando:

- validação e seleção de CNPJ na UI;
- workers e serviços assíncronos da interface;
- persistência local em Parquet por CNPJ;
- padrão de orquestração em duas fases;
- exportação e visualização em tabelas.

O novo requisito deve nascer como **um único motor de negócio** com dois disparadores:

- **execução unitária**: gera o dossiê para um CNPJ;
- **execução em lote**: percorre uma lista de CNPJs e chama o motor unitário.

## Observação importante

O pacote SQL recebido já está bem atomizado. O principal trabalho agora não é redesenhar o SQL, e sim:

- adaptar a resolução de contexto (`CNPJ`, `CO_CNPJ_CPF`, `CO_CAD_ICMS`, raiz);
- encaixar a extração na infraestrutura do `audit_react`;
- criar camada Polars de integração e marts finais do dossiê;
- abrir modo de consumo na interface.
