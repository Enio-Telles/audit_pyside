# Inventário das buscas realizadas

## 1. Buscas no repositório `audit_react`

### Consultas realizadas

1. Busca pelo repositório `audit_react`.
2. Busca por termos relacionados a `dossie cnpj polars parquet`.
3. Busca por `dossie`.
4. Busca por `polars parquet oracle sql`.
5. Busca genérica por `sql`.

### Arquivos abertos para análise

- `README.md`
- `src/orquestrador_pipeline.py`
- `app.py`
- `src/extracao/extrair_dados_cnpj.py`
- `src/interface_grafica/ui/main_window.py`
- `src/interface_grafica/services/pipeline_funcoes_service.py`
- `src/interface_grafica/config.py`

### O que essas buscas confirmaram

- O projeto trabalha com **persistência por CNPJ**.
- A arquitetura atual separa **extração Oracle** e **geração de tabelas**.
- A interface gráfica já possui infraestrutura reaproveitável para um novo domínio.
- O pipeline atual é fortemente orientado a execução unitária por contribuinte.
- Não foi localizada uma implementação já integrada de “dossiê CNPJ” dentro do `audit_react`.

## 2. Buscas no Google Drive

### Consultas realizadas

1. Busca por `dossie cnpj`.
2. Leitura da planilha `Modelo de Dossiê para Fiscalização Tributária`.
3. Leitura do documento `Modelo de Relatório de Fiscalização`.
4. Cruzamento com documentos funcionais que citam `Dossiê Contribuinte`, `Visão Contribuinte 360` e `Visão por Raiz do CNPJ`.

### O que essas buscas confirmaram

- Existe base documental ativa para o conceito funcional de **Dossiê Contribuinte**.
- Existe também a noção funcional de **visão por raiz do CNPJ**.
- Há um uso operacional do dossiê em rotinas de fiscalização e análise preliminar.
- Há um modelo simples de campos mínimos do dossiê em planilha.

## 3. Busca no pacote enviado pelo usuário

### Conteúdo analisado

Foi inspecionado o arquivo enviado:

- `dossie_sql_polars_otimizado.zip`

### Principais arquivos internos

- `README.md`
- `docs/matriz_dependencias.md`
- `docs/ordem_execucao.md`
- `docs/plano_implementacao_polars.md`
- `docs/inventario_consultas.csv`
- `consultas_sql/00_base/*`
- `consultas_sql/10_cadastro/*`
- `consultas_sql/20_societario/*`
- `consultas_sql/30_documentos_fiscais/*`
- `consultas_sql/40_arrecadacao_regularidade/*`
- `consultas_sql/50_fiscalizacao_conformidade/*`
- `consultas_sql/90_orquestracao/*`

### O que essa análise confirmou

- O pacote já está organizado por domínio.
- Existe uma boa separação entre resolução de contribuinte, cadastro, societário, documentos, arrecadação e fiscalização.
- O pacote já traz uma lógica pensada para ser persistida em **Parquet** e consolidada em **Polars**.
- A principal lacuna não é de modelagem do dossiê, e sim de **integração com a arquitetura real do `audit_react`**.
