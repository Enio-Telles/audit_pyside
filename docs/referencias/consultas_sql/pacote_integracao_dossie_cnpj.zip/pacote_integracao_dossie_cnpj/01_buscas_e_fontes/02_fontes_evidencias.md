# Fontes e evidências utilizadas

## A. Documentação ativa do Google Drive

### 1. Modelo de Relatório de Fiscalização
**Uso:** evidencia uso operacional do dossiê na análise preliminar.

Pontos confirmados:
- o relatório menciona consolidação prévia com base em sistemas institucionais;
- o dossiê é tratado como insumo para ação fiscal;
- há integração funcional com dados cadastrais e documentos fiscais.

### 2. Modelo de Dossiê para Fiscalização Tributária
**Uso:** evidencia campos mínimos e estrutura simples de apresentação.

Pontos confirmados:
- DSF;
- processo;
- identificação do alvo;
- empresas vinculadas;
- situação da IE.

### 3. Manual funcional com SisMonitora / Visão Contribuinte 360 / Visão por Raiz do CNPJ
**Uso:** base documental funcional do conceito de dossiê.

Pontos confirmados:
- o termo `Dossiê Contribuinte` existe como funcionalidade institucional;
- a `Visão Contribuinte 360` reúne informações cadastrais, fiscais e documentais;
- a `Visão por Raiz do CNPJ` é uma visão agregada de estabelecimentos de uma mesma raiz.

## B. Repositório `audit_react`

### 1. `README.md`
**Uso:** definição da arquitetura vigente.

Pontos confirmados:
- extração Oracle para Parquet por CNPJ;
- transformação analítica modular;
- operação por interface gráfica.

### 2. `src/orquestrador_pipeline.py`
**Uso:** confirmação do pipeline oficial e do padrão de execução por CNPJ.

Pontos confirmados:
- entrada unitária por contribuinte;
- dependências explícitas entre etapas;
- pipeline oficial orientado a tabelas de negócio.

### 3. `src/extracao/extrair_dados_cnpj.py`
**Uso:** confirmação do padrão de extração atual.

Pontos confirmados:
- bind principal por `:CNPJ`;
- persistência em diretório dedicado por contribuinte;
- política defensiva para evitar extrações imensas quando a consulta não possui bind adequado.

### 4. `src/interface_grafica/ui/main_window.py`
**Uso:** identificação de pontos reaproveitáveis da UI.

Pontos confirmados:
- workers de execução;
- serviços desacoplados;
- padrão de novas abas e exportações;
- seleção de CNPJ e abertura de datasets em Parquet.

### 5. `src/interface_grafica/services/pipeline_funcoes_service.py`
**Uso:** identificação do padrão de serviço que deve ser replicado para o dossiê.

Pontos confirmados:
- separação entre serviço de extração e serviço de geração;
- orchestration service único;
- retorno estruturado com mensagens, arquivos gerados, erros e tempos.

## C. Pacote SQL/Polars enviado

### 1. `README.md`
**Uso:** visão geral da proposta.

### 2. `docs/matriz_dependencias.md`
**Uso:** dependências lógicas entre consultas.

### 3. `docs/ordem_execucao.md`
**Uso:** ordem sugerida de processamento.

### 4. `docs/plano_implementacao_polars.md`
**Uso:** proposta de arquitetura para persistência em Parquet e consolidação em Polars.

## Conclusão de autoridade técnica

### Mais forte para integração técnica
- implementação real do `audit_react`.

### Mais forte para escopo funcional do dossiê
- documentação ativa do Google Drive.

### Mais forte para desenho do novo domínio
- pacote SQL/Polars enviado.
