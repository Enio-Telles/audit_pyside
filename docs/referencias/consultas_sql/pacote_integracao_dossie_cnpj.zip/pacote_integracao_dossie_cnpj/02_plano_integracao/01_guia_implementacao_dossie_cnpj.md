# Guia de implementação do Dossiê CNPJ no `audit_react`

## 1. Objetivo

Implementar um novo domínio funcional chamado **Dossiê CNPJ**, capaz de:

- gerar o dossiê de um CNPJ individualmente;
- gerar o mesmo dossiê em lote para vários CNPJs;
- persistir resultados em Parquet;
- consolidar dados em Polars;
- expor o conteúdo na interface do projeto.

## 2. Princípio arquitetural recomendado

A decisão principal é:

> **não criar dois motores diferentes**.
>
> Criar **um único motor unitário de dossiê** e um **orquestrador de lote** que chama esse motor várias vezes.

Isso é o que melhor conversa com a arquitetura atual do projeto.

## 3. Como o `audit_react` já funciona hoje

O projeto atual já oferece:

- entrada por CNPJ;
- extração Oracle -> Parquet;
- geração de tabelas derivadas;
- serviços desacoplados;
- workers na UI;
- diretório físico por contribuinte.

Hoje, o padrão físico principal é:

```text
FUNCOES_ROOT/dados/CNPJ/<cnpj>/...
```

Isso deve ser preservado.

## 4. Onde o Dossiê CNPJ deve entrar

O dossiê não deve ser acoplado às tabelas de estoque/produtos.

A recomendação é criar um **novo domínio paralelo**.

### Estrutura sugerida

```text
src/
├─ dossie_cnpj/
│  ├─ __init__.py
│  ├─ contexto.py
│  ├─ resolver_contribuinte.py
│  ├─ extracao_sql.py
│  ├─ integracao_polars.py
│  ├─ marts.py
│  ├─ exportadores.py
│  └─ schemas.py
├─ interface_grafica/
│  ├─ services/
│  │  ├─ dossie_cnpj_service.py
│  │  └─ dossie_cnpj_batch_service.py
│  └─ ui/
│     └─ ... nova aba ou nova janela do dossiê ...
```

## 5. Estrutura física dos dados

Criar um namespace próprio para o novo domínio:

```text
dados/CNPJ/<cnpj>/dossie_cnpj/
├─ raw/
├─ silver/
├─ gold/
└─ manifests/
```

### Finalidade de cada camada

- `raw/`: saída de cada SQL singular.
- `silver/`: dados padronizados por domínio.
- `gold/`: visões finais para a UI e exportação.
- `manifests/`: rastro da execução, insumos, tempos e falhas.

## 6. Resolução de contexto do contribuinte

Esse é o primeiro ponto crítico da integração.

O pacote recebido usa mais de uma chave lógica:

- `CNPJ`
- `CO_CNPJ_CPF`
- `CO_CAD_ICMS`
- raiz do CNPJ

O repositório atual, por outro lado, está fortemente orientado a `:CNPJ`.

### Solução recomendada

Criar um objeto de contexto canônico.

```python
from dataclasses import dataclass

@dataclass
class ContextoDossieCNPJ:
    cnpj_consulta: str
    raiz_cnpj: str | None
    co_cnpj_cpf: str | None
    co_cad_icms: str | None
    ie: str | None
    nome: str | None
    data_referencia: str | None
    periodo_ini: str | None
    periodo_fim: str | None
    id_execucao: str
```

### Regra

Nenhuma consulta do dossiê deve ser disparada antes de resolver esse contexto.

## 7. Adaptação dos SQLs do pacote

O pacote já está suficientemente bom para virar fonte principal de extração.

### Estratégia prática

1. copiar o pacote SQL para um espaço próprio do projeto;
2. padronizar nomes de bind, ou criar um adaptador;
3. executar cada consulta individualmente;
4. salvar cada resultado em Parquet.

### Melhor abordagem

Não reescrever tudo para `:CNPJ` imediatamente.

Criar uma camada adaptadora que monte os binds reais de cada SQL.

Exemplo conceitual:

```python
def montar_binds_dossie(contexto: ContextoDossieCNPJ) -> dict:
    return {
        "CNPJ": contexto.cnpj_consulta,
        "CO_CNPJ_CPF": contexto.co_cnpj_cpf,
        "CO_CAD_ICMS": contexto.co_cad_icms,
        "IE": contexto.ie,
        "NOME": contexto.nome,
    }
```

## 8. Serviços novos recomendados

### 8.1. Serviço unitário

Criar algo análogo ao padrão já usado em `pipeline_funcoes_service.py`.

```python
class ServicoDossieCNPJ:
    def executar_unitario(self, contexto, progresso=None):
        ...
```

Responsabilidades:
- resolver contexto;
- executar SQLs por domínio;
- salvar `raw/`;
- montar `silver/`;
- gerar `gold/`;
- gerar manifesto.

### 8.2. Serviço de lote

```python
class ServicoDossieCNPJLote:
    def executar_lote(self, lista_contextos, progresso=None):
        ...
```

Responsabilidades:
- validar lista;
- iterar pelos CNPJs;
- chamar o serviço unitário;
- registrar sucesso/falha;
- consolidar relatório do lote.

## 9. Execução unitária: fluxo recomendado

```text
entrada do usuário
-> sanitizar CNPJ
-> resolver contribuinte
-> montar contexto canônico
-> executar SQLs base
-> executar SQLs dos domínios
-> salvar raw por consulta
-> integrar silver por domínio
-> gerar gold do dossiê
-> salvar manifesto
-> publicar na UI
```

## 10. Execução em lote: fluxo recomendado

```text
lista de CNPJs
-> sanitizar lista
-> deduplicar
-> resolver contexto mínimo de cada item
-> enfileirar execuções
-> chamar motor unitário para cada CNPJ
-> registrar status por item
-> gerar relatório consolidado do lote
```

## 11. Marts finais sugeridos

Criar no mínimo estes datasets finais.

### 11.1. `gold_dossie_resumo`
Uma linha por contribuinte.

Campos sugeridos:
- identificação principal;
- situação cadastral;
- regime atual;
- contagem de sócios atuais;
- total de ações fiscais;
- total de autos de infração;
- total de notificações;
- total de parcelamentos;
- flags de risco.

### 11.2. `gold_dossie_timeline`
Histórico navegável de eventos.

Campos sugeridos:
- `tipo_evento`
- `subtipo_evento`
- `data_evento`
- `descricao_curta`
- `origem_sistema`
- `chave_evento`
- `valor_evento`
- `co_cnpj_cpf`

### 11.3. `gold_dossie_cadastro`
Visão temática de cadastro.

### 11.4. `gold_dossie_societario`
Visão temática de quadro societário e empresas relacionadas.

### 11.5. `gold_dossie_documental`
Visão temática de NF-e/NFC-e/MDF-e/VAF/IP transmissor.

### 11.6. `gold_dossie_regularidade`
Conta corrente, parcelamentos, DIMP e confrontos.

### 11.7. `gold_dossie_fiscalizacao`
Vistorias, ações fiscais, DSF, autos, notificações e conformidade.

## 12. Persistência e rastreabilidade

Toda execução deve produzir um manifesto.

### Exemplo de conteúdo do manifesto
- `id_execucao`
- `cnpj`
- `co_cnpj_cpf`
- `co_cad_icms`
- `modo_execucao`
- `sqls_executados`
- `arquivos_gerados`
- `tempos_por_etapa`
- `falhas`
- `status_final`

## 13. Integração com a UI

A UI atual já tem padrão pronto para isso.

### Opção mais segura

Criar uma nova aba `Dossiê CNPJ` com:

- campo de entrada de CNPJ;
- botão `Gerar dossiê`;
- botão `Gerar lote`;
- painel lateral de artefatos do dossiê;
- abas internas temáticas:
  - resumo;
  - timeline;
  - cadastro;
  - societário;
  - documentos;
  - regularidade;
  - fiscalização.

### Reuso real da UI existente

Reaproveitar:
- `ServiceTaskWorker`;
- `PipelineWorker` como referência de padrão;
- tabelas `QTableView`;
- exportação Excel;
- navegação por CNPJ;
- persistência de perfis/colunas.

## 14. Recomendação de implantação por fases

### Fase 1 — motor unitário mínimo viável
Implementar:
- resolução de contexto;
- extração `00_base`;
- extração de 2 ou 3 domínios prioritários;
- `gold_dossie_resumo`;
- `gold_dossie_timeline`.

### Fase 2 — UI funcional
Implementar:
- aba do dossiê;
- leitura dos marts finais;
- filtros e exportação.

### Fase 3 — lote
Implementar:
- leitura de lista de CNPJs;
- fila controlada;
- manifesto consolidado do lote.

### Fase 4 — visão por raiz
Implementar:
- consolidação de estabelecimentos da mesma raiz;
- mart agregado por raiz;
- navegação entre visão estabelecimento e visão raiz.

## 15. Decisão final recomendada

### Faça assim
- um novo domínio `dossie_cnpj`;
- um motor unitário;
- um orquestrador de lote por cima desse motor;
- persistência por CNPJ em `raw/silver/gold`;
- UI própria do dossiê.

### Evite
- misturar o dossiê com `analises/produtos`;
- criar um lote que execute SQL global sem isolamento por contribuinte;
- reescrever o pacote em uma SQL monolítica;
- publicar só a saída final sem manifesto e sem persistência intermediária.
