# Plano operacional para modo unitário e modo em lote

## 1. Regra principal

O lote deve ser um **orquestrador**.

O unitário deve ser o **motor real do negócio**.

## 2. Modo unitário

### Entrada
- um CNPJ;
- opcionalmente data de referência;
- opcionalmente período.

### Saídas esperadas
- parquets `raw`;
- parquets `silver`;
- parquets `gold`;
- manifesto de execução.

### Pseudocódigo

```python
def executar_dossie_unitario(cnpj: str, data_ref: str | None = None):
    contexto = resolver_contexto(cnpj=cnpj, data_referencia=data_ref)
    extrair_consultas_base(contexto)
    extrair_consultas_cadastro(contexto)
    extrair_consultas_societario(contexto)
    extrair_consultas_documentos(contexto)
    extrair_consultas_regularidade(contexto)
    extrair_consultas_fiscalizacao(contexto)
    gerar_silver(contexto)
    gerar_gold(contexto)
    salvar_manifesto(contexto)
    return contexto
```

## 3. Modo em lote

### Entrada
- lista de CNPJs;
- parâmetros comuns do lote;
- paralelismo máximo.

### Saídas esperadas
- uma execução unitária por CNPJ;
- relatório consolidado do lote;
- lista de sucessos e falhas;
- possibilidade de reprocesso de falhos.

### Pseudocódigo

```python
def executar_dossie_lote(lista_cnpjs: list[str], max_workers: int = 2):
    fila = preparar_fila(lista_cnpjs)
    resultados = []
    for item in fila:
        try:
            resultado = executar_dossie_unitario(item.cnpj)
            resultados.append({"cnpj": item.cnpj, "status": "ok"})
        except Exception as exc:
            resultados.append({"cnpj": item.cnpj, "status": "erro", "erro": str(exc)})
    salvar_relatorio_lote(resultados)
    return resultados
```

## 4. Política de concorrência

### Recomendação prática

Começar com paralelismo baixo:
- `max_workers = 2` ou `3`

Motivo:
- as consultas Oracle podem ser pesadas;
- o projeto atual não parece desenhado para explosão de concorrência nesse domínio;
- é melhor estabilidade do que throughput alto na primeira versão.

## 5. Relatório consolidado do lote

Sugestão de campos:
- `id_lote`
- `data_execucao`
- `cnpj`
- `status`
- `tempo_total_segundos`
- `etapa_falha`
- `mensagem_erro`
- `caminho_manifesto`

## 6. Critérios de falha por item

Marcar como falho quando ocorrer:
- contribuinte não resolvido;
- múltiplos matches sem desempate;
- falha de conexão Oracle;
- erro de SQL;
- erro de persistência;
- falha de integração Polars.

## 7. Critérios de sucesso parcial

Pode haver sucesso parcial quando:
- parte dos domínios vier vazia por ausência legítima de dado;
- mas a resolução do contribuinte e a geração dos marts principais tiverem ocorrido.

Nesse caso:
- `status = ok_com_alertas`
- registrar domínio vazio no manifesto.

## 8. Reprocesso

O lote deve permitir:
- reprocessar apenas falhos;
- reprocessar apenas um subconjunto filtrado;
- repetir com nova data de referência.

## 9. Política de armazenamento

### Unitário

```text
dados/CNPJ/<cnpj>/dossie_cnpj/
```

### Lote

```text
workspace/dossie_lote/
├─ lotes/
│  └─ <id_lote>.json
└─ relatorios/
   └─ <id_lote>.parquet
```

## 10. Decisão recomendada

### Primeira entrega
- finalizar o modo unitário;
- estabilizar os marts finais;
- só depois liberar o lote.

### Segunda entrega
- lote com relatório consolidado;
- reprocesso de falhos;
- fila com concorrência controlada.
