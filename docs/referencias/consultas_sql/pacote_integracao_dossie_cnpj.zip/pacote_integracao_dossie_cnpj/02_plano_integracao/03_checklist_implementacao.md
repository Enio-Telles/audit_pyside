# Checklist de implementação

## Fase 0 — Preparação
- [ ] Criar namespace `src/dossie_cnpj/`
- [ ] Criar namespace físico `dados/CNPJ/<cnpj>/dossie_cnpj/`
- [ ] Copiar o pacote SQL para a estrutura do projeto
- [ ] Definir padrão de bind e contexto canônico

## Fase 1 — Resolução do contribuinte
- [ ] Implementar `ContextoDossieCNPJ`
- [ ] Implementar resolução de `co_cnpj_cpf`
- [ ] Implementar resolução de `co_cad_icms`
- [ ] Implementar validação de ambiguidade
- [ ] Implementar resolução da raiz do CNPJ

## Fase 2 — Extração SQL
- [ ] Criar executor de SQL do dossiê
- [ ] Adaptar binds do pacote
- [ ] Persistir uma saída `raw` por consulta
- [ ] Registrar tempo por consulta
- [ ] Registrar falha por consulta

## Fase 3 — Integração Polars
- [ ] Padronizar tipos e datas
- [ ] Criar datasets `silver` por domínio
- [ ] Criar `gold_dossie_resumo`
- [ ] Criar `gold_dossie_timeline`
- [ ] Criar marts temáticos adicionais

## Fase 4 — UI
- [ ] Criar aba ou janela `Dossiê CNPJ`
- [ ] Adicionar ação `Gerar dossiê`
- [ ] Adicionar filtros e exportação
- [ ] Adicionar leitura dos marts `gold`

## Fase 5 — Lote
- [ ] Criar serviço de lote
- [ ] Ler lista de CNPJs
- [ ] Deduplicar e validar itens
- [ ] Controlar concorrência
- [ ] Gerar relatório consolidado do lote
- [ ] Permitir reprocesso de falhos

## Fase 6 — Rastreabilidade
- [ ] Salvar manifesto por execução
- [ ] Salvar relatório por lote
- [ ] Versionar a regra de processamento
- [ ] Registrar SQLs executados e arquivos gerados
